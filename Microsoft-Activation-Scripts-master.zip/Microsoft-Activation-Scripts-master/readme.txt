Nhấp chuột phải vào tệp zip đã tải xuống và giải nén
Trong thư mục được giải nén, tìm thư mục có tên All-In-One-Version
Chạy tệp có tên MAS_AIO.cmd
Bạn sẽ thấy các tùy chọn kích hoạt và làm theo hướng dẫn trên màn hình.
Đó là tất cả.